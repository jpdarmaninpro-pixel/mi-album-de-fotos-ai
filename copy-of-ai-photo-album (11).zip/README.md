# AI Photo Album

A professional photo album web app with AI-powered image editing and album creation features. This project is structured as a full-stack application with a React frontend and a Node.js/Express backend, designed for secure and scalable deployment.